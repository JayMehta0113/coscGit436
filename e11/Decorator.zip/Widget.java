public interface Widget {
    public void draw();
}
