package observer;

public interface AlarmListener {
    void alarm();
}
